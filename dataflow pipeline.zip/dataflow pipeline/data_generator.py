#!/usr/bin/env python3
"""
data_generator.py
Data generator for Project 21: Ride-Sharing Surge Pricing Signals.
Publishes ride-sharing events to Google Pub/Sub.
"""

import argparse
import json
import random
import time
import uuid
from datetime import datetime, timedelta, timezone

from google.cloud import pubsub_v1

# Geographic zones (5 rows A-E, 5 columns 1-5)
ZONES = [f"ZONE-{chr(65 + i)}{j}" for i in range(5) for j in range(1, 6)]

# NYC-ish base coordinates
LAT_BASE, LON_BASE = 40.75, -73.98


def generate_record(recent_records: list) -> dict:
    """Generate a single ride-sharing event."""
    zone = random.choice(ZONES)
    zone_row = ord(zone.split("-")[1][0]) - 65
    zone_col = int(zone.split("-")[1][1]) - 1

    lat = LAT_BASE + zone_row * 0.01 + random.uniform(-0.005, 0.005)
    lon = LON_BASE + zone_col * 0.01 + random.uniform(-0.005, 0.005)

    # Event time: 10% chance of late data (1-5 minutes late)
    event_time = datetime.now(timezone.utc)
    if random.random() < 0.10:
        event_time -= timedelta(minutes=random.uniform(1, 5))

    # Simulate rush hour: ~55% ride requests, ~29% driver available, ~16% other
    rand_val = random.random()
    if rand_val < 0.55:
        evt = "ride_request"
        rider_id = f"RDR-{random.randint(10000, 99999)}"
        driver_id = None
        dlat = round(lat + random.uniform(-0.03, 0.03), 6)
        dlon = round(lon + random.uniform(-0.03, 0.03), 6)
    elif rand_val < 0.84:
        evt = "driver_available"
        rider_id = None
        driver_id = f"DRV-{random.randint(1000, 9999)}"
        dlat = None
        dlon = None
    else:
        evt = random.choice(["ride_accepted", "ride_started", "ride_completed"])
        rider_id = f"RDR-{random.randint(10000, 99999)}"
        driver_id = f"DRV-{random.randint(1000, 9999)}"
        dlat = round(lat + random.uniform(-0.03, 0.03), 6)
        dlon = round(lon + random.uniform(-0.03, 0.03), 6)

    # 5% chance to resend a recent record (duplicate simulation)
    if random.random() < 0.05 and recent_records:
        record = random.choice(recent_records).copy()
        record["request_id"] = f"REQ-{uuid.uuid4().hex[:10].upper()}"
        return record

    return {
        "request_id": f"REQ-{uuid.uuid4().hex[:10].upper()}",
        "rider_id": rider_id,
        "driver_id": driver_id,
        "event_type": evt,
        "pickup_lat": round(lat, 6),
        "pickup_lon": round(lon, 6),
        "dropoff_lat": dlat,
        "dropoff_lon": dlon,
        "zone_id": zone,
        "event_time": event_time.isoformat(),
    }


def main():
    parser = argparse.ArgumentParser(description="Ride-sharing event data generator")
    parser.add_argument("--project-id", required=True, help="GCP project ID")
    parser.add_argument("--duration", type=int, default=60,
                        help="Duration in seconds (default: 60)")
    parser.add_argument("--rate", type=float, default=5.0,
                        help="Messages per second (default: 5)")
    args = parser.parse_args()

    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(args.project_id, "spark-21-ridesharing")

    print(f"Publishing to {topic_path} at {args.rate} msgs/sec for {args.duration}s")
    print("\nSample records:")

    start = time.time()
    count = 0
    recent: list = []
    futures = []

    while time.time() - start < args.duration:
        record = generate_record(recent)

        # Maintain sliding window of recent records for duplicate simulation
        recent.append(record)
        if len(recent) > 20:
            recent.pop(0)

        data = json.dumps(record).encode("utf-8")
        future = publisher.publish(topic_path, data)
        futures.append(future)
        count += 1

        if count <= 3:
            print(json.dumps(record, indent=2))

        time.sleep(1.0 / args.rate)

    # Wait for all publishes to complete
    for future in futures:
        try:
            future.result(timeout=30)
        except Exception as e:
            print(f"Warning: publish failed: {e}")

    print(f"\nPublished {count} messages in {args.duration} seconds.")


if __name__ == "__main__":
    main()
