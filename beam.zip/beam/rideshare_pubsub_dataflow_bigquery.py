#!/usr/bin/env python3
"""
rideshare_pubsub_dataflow_bigquery.py
Airflow DAG — Infrastructure Setup + Dataflow Launch (runs ONCE, triggered manually)

This is the FIRST DAG in the project. It:
  1. Creates the Pub/Sub topic and subscription
  2. Creates the BigQuery dataset and raw_events table (with updated schema)
  3. Launches the Dataflow streaming pipeline (runs forever in background)

NOTE: This DAG intentionally has NO downstream tasks after the Dataflow launch.
The surge metrics computation and Looker view are handled by the separate
bq_transform_dag.py (schedule: every 5 minutes) because Dataflow is a
streaming job that never finishes — it cannot have downstream tasks in Airflow.
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.google.cloud.operators.pubsub import (
    PubSubCreateTopicOperator,
    PubSubCreateSubscriptionOperator,
)
from airflow.providers.apache.beam.operators.beam import BeamRunPythonPipelineOperator
from airflow.providers.google.cloud.operators.bigquery import (
    BigQueryCreateEmptyDatasetOperator,
    BigQueryInsertJobOperator,
)
from airflow.providers.google.cloud.operators.dataflow import DataflowConfiguration

# ─── CONFIG ────────────────────────────────────────────────────────────────
PROJECT_ID   = "sprint-project123"
REGION       = "europe-west8"
BUCKET       = "ridesh"
DATASET      = "analytics"
TOPIC        = "spark-21-ridesharing"
SUBSCRIPTION = "spark-21-ridesharing-sub"
RAW_TABLE    = "raw_events2"


# ─── SQL: CREATE raw_events TABLE ──────────────────────────────────────────
# Updated schema — matches the BQ_SCHEMA in rideshare_streaming_pipeline.py
# Partitioned by DATE(event_time) for query performance and cost control
CREATE_RAW_TABLE_SQL = f"""
CREATE TABLE IF NOT EXISTS `{PROJECT_ID}.{DATASET}.{RAW_TABLE}`
(
    -- Event identity
    request_id   STRING    OPTIONS(description='Unique request/event identifier'),
    rider_id     STRING    OPTIONS(description='Rider ID; NULL for driver events'),
    driver_id    STRING    OPTIONS(description='Driver ID; NULL for rider events'),

    -- Event classification
    event_type   STRING    OPTIONS(description='ride_request | driver_available | ride_accepted | ride_started | ride_completed'),

    -- GPS coordinates
    pickup_lat   FLOAT64   OPTIONS(description='Pickup latitude'),
    pickup_lon   FLOAT64   OPTIONS(description='Pickup longitude'),
    dropoff_lat  FLOAT64   OPTIONS(description='Dropoff latitude; NULL for driver_available'),
    dropoff_lon  FLOAT64   OPTIONS(description='Dropoff longitude; NULL for driver_available'),

    -- Zone
    zone_id      STRING    OPTIONS(description='Pre-computed geographic zone e.g. ZONE-A1, ZONE-B3'),

    -- Timestamps
    event_time   TIMESTAMP OPTIONS(description='Original event timestamp from the ride app (event-time, not processing-time)')
)
PARTITION BY DATE(event_time)
OPTIONS(
    description = 'Raw ride-sharing events written by Dataflow streaming pipeline. Partitioned by event_time date for cost efficiency.'
)
"""


# ─── DAG DEFAULTS ──────────────────────────────────────────────────────────
default_args = {
    "owner":           "airflow",
    "retries":         1,
    "retry_delay":     timedelta(minutes=5),
    "start_date":      datetime(2024, 1, 1),
    "depends_on_past": False,
}


# ─── DAG DEFINITION ────────────────────────────────────────────────────────
with DAG(
    dag_id           = "rideshare_pubsub_dataflow_bigquery",
    schedule_interval = None,             # Manual trigger only (run once for setup)
    default_args     = default_args,
    catchup          = False,
    tags             = ["pubsub", "dataflow", "bigquery", "setup"],
    description      = "One-time infrastructure setup: PubSub + BigQuery + Dataflow launch",
) as dag:

    # ── Task 1: Create Pub/Sub topic ───────────────────────────────────────
    # fail_if_exists=False → safe to re-run if topic already exists
    create_topic = PubSubCreateTopicOperator(
        task_id        = "create_pubsub_topic",
        project_id     = PROJECT_ID,
        topic          = TOPIC,
        fail_if_exists = False,
        do_xcom_push   = False,
    )

    # ── Task 2: Create Pub/Sub subscription ───────────────────────────────
    # The Dataflow pipeline reads from this subscription (pull mode)
    create_subscription = PubSubCreateSubscriptionOperator(
        task_id        = "create_pubsub_subscription",
        project_id     = PROJECT_ID,
        topic          = TOPIC,
        subscription   = SUBSCRIPTION,
        fail_if_exists = False,
        do_xcom_push   = False,
    )

    # ── Task 3: Create BigQuery dataset ───────────────────────────────────
    # location=EU matches the Dataflow region (europe-west8)
    create_dataset = BigQueryCreateEmptyDatasetOperator(
        task_id    = "create_bq_dataset",
        project_id = PROJECT_ID,
        dataset_id = DATASET,
        location   = "EU",
        if_exists  = "ignore",           # Skip if dataset already exists
    )

    # ── Task 4: Create raw_events table with updated schema ───────────────
    create_raw_table = BigQueryInsertJobOperator(
        task_id       = "create_raw_table",
        configuration = {
            "query": {
                "query":        CREATE_RAW_TABLE_SQL,
                "useLegacySql": False,
            }
        },
    )

    # ── Task 5: Launch Dataflow streaming pipeline ─────────────────────────
    # Reads rideshare_streaming_pipeline.py from GCS and submits to Dataflow.
    # wait_until_finish=False is CRITICAL — the pipeline runs forever (streaming).
    # Airflow marks this task as SUCCESS as soon as the Dataflow job is submitted,
    # then moves on. The Dataflow job continues running in the background.
    start_dataflow = BeamRunPythonPipelineOperator(
        task_id          = "run_dataflow_streaming",
        py_file          = f"gs://{BUCKET}/dataflow/rideshare_streaming_pipeline1.py",
        py_interpreter   = "python3",
        pipeline_options = {
            "project":          PROJECT_ID,
            "region":           REGION,
            "runner":           "DataflowRunner",
            "streaming":        True,                        # Infinite Pub/Sub stream
            "temp_location":    f"gs://{BUCKET}/temp",
            "staging_location": f"gs://{BUCKET}/staging",
            "job_name":         "rideshare-stream-to-bq",
            "save_main_session": True,
        },
        dataflow_config = DataflowConfiguration(
            project_id        = PROJECT_ID,
            location          = REGION,
            wait_until_finished=False,      # Don't block — streaming jobs never end
        ),
    )

    # ── Task Dependencies ──────────────────────────────────────────────────
    #
    #   create_topic
    #       └── create_subscription ──┐
    #                                 ├── create_raw_table ── start_dataflow
    #       create_dataset ───────────┘
    #
    # Pub/Sub topic must exist before subscription is created.
    # Dataset must exist before table is created.
    # Both subscription and table must exist before Dataflow starts.

    create_topic >> create_subscription
    create_dataset >> create_raw_table
    [create_subscription, create_raw_table] >> start_dataflow

    # NOTE: No tasks after start_dataflow intentionally.
    # Surge metrics + Looker view are handled by bq_transform_dag.py
