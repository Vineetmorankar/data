#!/usr/bin/env python3
"""
bq_transform_dag.py
Airflow DAG — BigQuery Analytics & Looker View (runs every 5 minutes)

This is the SECOND DAG in the project. It is intentionally separate from
the main setup DAG (rideshare_pubsub_dataflow_bigquery.py) because:
  - The Dataflow streaming job runs forever (never "finishes")
  - So compute_surge_metrics and create_looker_view can never be downstream
    of a forever-running task in the same DAG
  - This DAG runs on its own 5-minute schedule independently

Tasks:
  1. transform_surge_metrics  — reads raw_events, computes surge per zone per
                                 5-min window, writes to zone_surge_metrics table
  2. create_looker_view       — creates/refreshes a sorted view for dashboards
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator

# ─── CONFIG ────────────────────────────────────────────────────────────────
PROJECT_ID   = "sprint-project123"
DATASET      = "analytics"
SOURCE_TABLE = "raw_events2"
AGG_TABLE    = "zone_surge_metrics"
VIEW_NAME    = "looker_surge_view"


# ─── SQL: SURGE METRICS TRANSFORMATION ─────────────────────────────────────
# Reads from raw_events (written by Dataflow every few seconds)
# Groups by zone_id and 5-minute tumbling window
# Computes demand, supply, surge multiplier, hotspot flag, and zone status
TRANSFORM_SQL = f"""
CREATE OR REPLACE TABLE `{PROJECT_ID}.{DATASET}.{AGG_TABLE}` AS

WITH base AS (
    SELECT
        -- Build 5-minute tumbling window boundaries from event_time
        -- TIMESTAMP_SECONDS(DIV(UNIX_SECONDS(event_time), 300) * 300)
        -- rounds each timestamp DOWN to the nearest 5-minute mark
        TIMESTAMP_SECONDS(
            DIV(UNIX_SECONDS(event_time), 300) * 300
        ) AS window_start,

        TIMESTAMP_SECONDS(
            DIV(UNIX_SECONDS(event_time), 300) * 300 + 300
        ) AS window_end,

        zone_id,

        -- Conditional aggregation: count demand vs supply in one pass
        COUNTIF(event_type = 'ride_request')    AS demand_count,
        COUNTIF(event_type = 'driver_available') AS supply_count

    FROM `{PROJECT_ID}.{DATASET}.{SOURCE_TABLE}`

    -- Only process the last 24 hours to keep the table fresh and small
    WHERE event_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)

    -- Group by zone + window so each row = one zone's 5-min stats
    GROUP BY window_start, window_end, zone_id
)

SELECT
    window_start,
    window_end,
    zone_id,
    demand_count,
    supply_count,

    -- SURGE MULTIPLIER FORMULA
    -- Step 1: GREATEST(supply_count, 1) → prevents division by zero
    --         if no drivers are available, treat supply as 1 (worst case)
    -- Step 2: SAFE_DIVIDE(demand, supply) → raw ratio
    -- Step 3: GREATEST(1.0, ...) → surge never goes below 1x (normal price)
    -- Step 4: LEAST(5.0, ...) → surge never exceeds 5x (company cap)
    LEAST(
        5.0,
        GREATEST(
            1.0,
            SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1))
        )
    ) AS surge_multiplier,

    -- HOTSPOT FLAG: True if surge > 2x (zone needs more drivers)
    SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1)) > 2.0 AS is_hotspot,

    -- ZONE STATUS LABEL: human-readable tier for dashboards
    -- Makes it easy to filter/color-code zones in Looker/Looker Studio
    CASE
        WHEN SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1)) >= 4.0
            THEN 'CRITICAL'   -- 4x+ surge: extremely high demand
        WHEN SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1)) >= 2.0
            THEN 'SURGE'      -- 2x–4x: hotspot zone
        WHEN SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1)) >= 1.2
            THEN 'ELEVATED'   -- 1.2x–2x: slightly above normal
        ELSE
            'NORMAL'          -- 1x: supply meets demand
    END AS zone_status

FROM base
"""


# ─── SQL: LOOKER VIEW ───────────────────────────────────────────────────────
# Creates a view on top of zone_surge_metrics, sorted for dashboards:
#   - Most recent window first
#   - Highest surge within each window first
# Looker Studio / Data Studio can connect directly to this view
VIEW_SQL = f"""
CREATE OR REPLACE VIEW `{PROJECT_ID}.{DATASET}.{VIEW_NAME}` AS
SELECT
    window_start,
    window_end,
    zone_id,
    demand_count,
    supply_count,
    surge_multiplier,
    is_hotspot,
    zone_status,

    -- Convenience column: human-readable window label for chart axes
    CONCAT(
        FORMAT_TIMESTAMP('%H:%M', window_start),
        ' – ',
        FORMAT_TIMESTAMP('%H:%M', window_end)
    ) AS window_label

FROM `{PROJECT_ID}.{DATASET}.{AGG_TABLE}`
ORDER BY window_start DESC, surge_multiplier DESC
"""


# ─── DAG DEFAULTS ──────────────────────────────────────────────────────────
default_args = {
    "owner":           "airflow",
    "start_date":      datetime(2024, 1, 1),
    "retries":         2,                        # retry twice on BQ failures
    "retry_delay":     timedelta(minutes=2),
    "depends_on_past": False,
}


# ─── DAG DEFINITION ────────────────────────────────────────────────────────
with DAG(
    dag_id          = "bq_surge_metrics_and_looker",
    schedule_interval = "*/5 * * * *",          # Run every 5 minutes
    default_args    = default_args,
    catchup         = False,                     # Don't backfill missed runs
    max_active_runs = 1,                         # Prevent overlapping runs
    tags            = ["bigquery", "analytics", "surge", "looker"],
    description     = "Computes zone-level surge metrics from raw_events2 every 5 min",
) as dag:

    # ── Task 1: Read raw_events → compute surge → write zone_surge_metrics ─
    transform_metrics = BigQueryInsertJobOperator(
        task_id     = "transform_surge_metrics",
        configuration = {
            "query": {
                "query":        TRANSFORM_SQL,
                "useLegacySql": False,
            }
        },
    )

    # ── Task 2: Refresh Looker view on top of zone_surge_metrics ───────────
    create_looker_view = BigQueryInsertJobOperator(
        task_id     = "create_looker_view",
        configuration = {
            "query": {
                "query":        VIEW_SQL,
                "useLegacySql": False,
            }
        },
    )

    # ── Task Dependencies ──────────────────────────────────────────────────
    # Must compute surge first, then refresh the view on top of it
    transform_metrics >> create_looker_view
