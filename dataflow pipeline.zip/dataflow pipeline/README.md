# Project 21: Ride-Sharing Surge Pricing Signals

## Difficulty: Hard
## Time Limit: 120 min

## Scenario
A ride-sharing company needs to dynamically adjust pricing based on real-time supply and demand. When ride requests in a geographic zone exceed available drivers, a surge multiplier is applied to attract more drivers to that area. The pricing engine requires per-zone demand/supply ratios computed every 5 minutes. Zones are defined by a grid system, and the system must identify "hotspot" zones where surge exceeds 2x.

## Problem Statement
Build a PySpark Structured Streaming application that reads ride-sharing events from Google Pub/Sub, buckets events into geographic zones, and computes demand (ride requests) vs supply (available drivers) per zone per 5-minute tumbling window. Calculate surge multipliers and identify hotspot zones.

## Input Schema
| Field | Type | Description |
|-------|------|-------------|
| request_id | string | Unique request/event identifier |
| rider_id | string | Rider identifier (null for driver events) |
| driver_id | string | Driver identifier (null for rider events) |
| event_type | string | One of: ride_request, driver_available, ride_accepted, ride_started, ride_completed |
| pickup_lat | float | Pickup latitude |
| pickup_lon | float | Pickup longitude |
| dropoff_lat | float | Dropoff latitude (null for driver_available) |
| dropoff_lon | float | Dropoff longitude (null for driver_available) |
| zone_id | string | Pre-computed geographic zone identifier (e.g., ZONE-A1, ZONE-B3) |
| event_time | string | ISO 8601 timestamp of the event |

## Pub/Sub Configuration
- **Project ID:** `your-gcp-project-id` (replace with yours)
- **Topic:** `spark-21-ridesharing`
- **Subscription:** `spark-21-ridesharing-sub`

## Requirements
1. Read ride-sharing events from Pub/Sub with a watermark of 5 minutes on `event_time`.
2. Compute 5-minute tumbling window aggregations per `zone_id`:
   - `demand_count`: number of `ride_request` events
   - `supply_count`: number of `driver_available` events
3. Calculate `surge_multiplier`: when demand > supply, multiplier = `max(1.0, demand_count / max(supply_count, 1))`, capped at 5.0.
4. Flag `hotspot_zones` where `surge_multiplier > 2.0`.
5. Output all zones with their supply/demand metrics in update mode.

## Expected Output Schema
| Field | Type | Description |
|-------|------|-------------|
| window_start | timestamp | Start of the 5-minute window |
| window_end | timestamp | End of the 5-minute window |
| zone_id | string | Geographic zone identifier |
| demand_count | long | Number of ride requests |
| supply_count | long | Number of available drivers |
| surge_multiplier | float | Demand/supply ratio (minimum 1.0, maximum 5.0) |
| is_hotspot | boolean | True if surge_multiplier > 2.0 |

## Evaluation Criteria
| Criteria | Weight | Description |
|----------|--------|-------------|
| Correctness | 40% | Accurate demand/supply counting, correct surge calculation, proper hotspot detection |
| Stream handling | 25% | Proper windowing, watermarking, handling of different event types |
| Code quality | 20% | Clean event filtering, proper geo-zone handling, readable pipeline |
| Fault tolerance | 15% | Checkpointing, division-by-zero protection, handling zones with no supply |

## Constraints
- Use PySpark Structured Streaming (not DStreams)
- Read from Google Pub/Sub using spark-sql-pubsub connector
- Handle late data arriving up to 5 minutes late
- Output mode: update

## Hints (optional, reveal if stuck)
<details>
<summary>Hint 1</summary>
Filter the stream into demand events (`event_type == "ride_request"`) and supply events (`event_type == "driver_available"`) before aggregation, then union or join the results.
</details>
<details>
<summary>Hint 2</summary>
An alternative approach: use conditional aggregation in a single groupBy: `count(when(col("event_type") == "ride_request", 1)).alias("demand_count")` and similarly for supply.
</details>
<details>
<summary>Hint 3</summary>
Always protect against division by zero: `when(col("supply_count") > 0, col("demand_count") / col("supply_count")).otherwise(lit(5.0))` — if there are zero drivers, set surge to max.
</details>
