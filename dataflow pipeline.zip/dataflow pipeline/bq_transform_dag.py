from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator

PROJECT_ID = "sprint-project123"
DATASET    = "analytics"

SOURCE_TABLE = "raw_events"
AGG_TABLE    = "zone_surge_metrics"
VIEW_NAME    = "looker_surge_view"


TRANSFORM_SQL = f"""
CREATE OR REPLACE TABLE `{PROJECT_ID}.{DATASET}.{AGG_TABLE}` AS
WITH base AS (
  SELECT
    TIMESTAMP_SECONDS(DIV(UNIX_SECONDS(event_time), 300) * 300) AS window_start,
    TIMESTAMP_SECONDS(DIV(UNIX_SECONDS(event_time), 300) * 300 + 300) AS window_end,
    zone_id,
    COUNTIF(event_type = 'ride_request')     AS demand_count,
    COUNTIF(event_type = 'driver_available') AS supply_count
  FROM `{PROJECT_ID}.{DATASET}.{SOURCE_TABLE}`
  WHERE event_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)
  GROUP BY window_start, window_end, zone_id
)

SELECT
  window_start,
  window_end,
  zone_id,
  demand_count,
  supply_count,
  LEAST(
    5.0,
    GREATEST(
      1.0,
      SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1))
    )
  ) AS surge_multiplier,
  SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1)) > 2.0 AS is_hotspot
FROM base;
"""


VIEW_SQL = f"""
CREATE OR REPLACE VIEW `{PROJECT_ID}.{DATASET}.{VIEW_NAME}` AS
SELECT
  window_start,
  window_end,
  zone_id,
  demand_count,
  supply_count,
  surge_multiplier,
  is_hotspot
FROM `{PROJECT_ID}.{DATASET}.{AGG_TABLE}`
ORDER BY window_start DESC, surge_multiplier DESC;
"""


default_args = {
    "owner": "airflow",
    "start_date": datetime(2024, 1, 1),
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="bq_surge_metrics_and_looker",
    schedule_interval="*/5 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_runs=1,
    tags=["bigquery", "analytics", "looker"],
) as dag:

    transform_metrics = BigQueryInsertJobOperator(
        task_id="transform_surge_metrics",
        configuration={
            "query": {
                "query": TRANSFORM_SQL,
                "useLegacySql": False,
            }
        },
    )

    create_looker_view = BigQueryInsertJobOperator(
        task_id="create_looker_view",
        configuration={
            "query": {
                "query": VIEW_SQL,
                "useLegacySql": False,
            }
        },
    )

    transform_metrics >> create_looker_view