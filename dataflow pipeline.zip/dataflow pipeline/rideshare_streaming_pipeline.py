import json
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io.gcp.pubsub import ReadFromPubSub
from apache_beam.io.gcp.bigquery import WriteToBigQuery, BigQueryDisposition
from datetime import datetime

PROJECT_ID = "sprint-project123"
BUCKET = "ridesh"
REGION = "europe-west8"

SUBSCRIPTION = (
    f"projects/{PROJECT_ID}/subscriptions/spark-21-ridesharing-sub"
)

BQ_TABLE = f"{PROJECT_ID}:analytics.raw_events"

BQ_SCHEMA = {
    "fields": [
        {"name": "request_id",  "type": "STRING"},
        {"name": "rider_id",    "type": "STRING"},
        {"name": "driver_id",   "type": "STRING"},
        {"name": "event_type",  "type": "STRING"},
        {"name": "pickup_lat",  "type": "FLOAT"},
        {"name": "pickup_lon",  "type": "FLOAT"},
        {"name": "dropoff_lat", "type": "FLOAT"},
        {"name": "dropoff_lon", "type": "FLOAT"},
        {"name": "zone_id",     "type": "STRING"},
        {"name": "event_time",  "type": "TIMESTAMP"},
    ]
}

class ParseJson(beam.DoFn):
    def process(self, element):
        record = json.loads(element.decode("utf-8"))
        record["event_time"] = datetime.fromisoformat(
            record["event_time"].replace("Z", "+00:00")
        )
        yield record

def run():
    options = PipelineOptions(
        runner="DataflowRunner",
        project=PROJECT_ID,
        region=REGION,
        streaming=True,
        save_main_session=True,
        temp_location=f"gs://{BUCKET}/temp",
        staging_location=f"gs://{BUCKET}/staging",
    )

    with beam.Pipeline(options=options) as p:
        (
            p
            | "ReadPubSub" >> ReadFromPubSub(subscription=SUBSCRIPTION)
            | "ParseJSON" >> beam.ParDo(ParseJson())
            | "WriteToBigQuery" >> WriteToBigQuery(
                BQ_TABLE,
                schema=BQ_SCHEMA,
                write_disposition=BigQueryDisposition.WRITE_APPEND,
                create_disposition=BigQueryDisposition.CREATE_IF_NEEDED,
            )
        )

if __name__ == "__main__":
    run()
