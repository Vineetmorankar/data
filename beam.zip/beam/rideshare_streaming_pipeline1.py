#!/usr/bin/env python3
"""
rideshare_streaming_pipeline.py
Apache Beam / Google Dataflow streaming pipeline for Project 21.

What this pipeline does:
  1. Reads raw ride-sharing events from Google Pub/Sub
  2. Parses JSON and assigns each record's event_time as the Beam event timestamp
     (this enables TRUE event-time processing, not processing-time)
  3. Applies a 5-minute tumbling window with a 5-minute watermark allowance
     so late-arriving events (up to 5 mins late) are still counted correctly
  4. Filters only relevant event types: ride_request and driver_available
  5. Writes every windowed event to BigQuery raw_events table (append mode)
"""

import json
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io.gcp.pubsub import ReadFromPubSub
from apache_beam.io.gcp.bigquery import WriteToBigQuery, BigQueryDisposition
from apache_beam import window
from apache_beam.transforms.trigger import AfterWatermark, AfterCount, AccumulationMode
from apache_beam.transforms.window import TimestampedValue, FixedWindows
from datetime import datetime, timezone

# ─── CONFIG ────────────────────────────────────────────────────────────────
PROJECT_ID   = "sprint-project123"
BUCKET       = "ridesh"
REGION       = "europe-west8"
SUBSCRIPTION = f"projects/{PROJECT_ID}/subscriptions/spark-21-ridesharing-sub"
BQ_TABLE     = f"{PROJECT_ID}:analytics.raw_events2"

# BigQuery schema — matches the CREATE TABLE in the main DAG
BQ_SCHEMA = {
    "fields": [
        {"name": "request_id",    "type": "STRING",    "mode": "NULLABLE"},
        {"name": "rider_id",      "type": "STRING",    "mode": "NULLABLE"},
        {"name": "driver_id",     "type": "STRING",    "mode": "NULLABLE"},
        {"name": "event_type",    "type": "STRING",    "mode": "NULLABLE"},
        {"name": "pickup_lat",    "type": "FLOAT64",   "mode": "NULLABLE"},
        {"name": "pickup_lon",    "type": "FLOAT64",   "mode": "NULLABLE"},
        {"name": "dropoff_lat",   "type": "FLOAT64",   "mode": "NULLABLE"},
        {"name": "dropoff_lon",   "type": "FLOAT64",   "mode": "NULLABLE"},
        {"name": "zone_id",       "type": "STRING",    "mode": "NULLABLE"},
        {"name": "event_time",    "type": "TIMESTAMP", "mode": "REQUIRED"},
    ]
}

# Relevant event types — all others (ride_accepted, ride_started, etc.) are dropped
RELEVANT_EVENTS = {"ride_request", "driver_available"}


# ─── STEP 1: PARSE JSON + ASSIGN EVENT TIMESTAMP ───────────────────────────
class ParseJsonWithTimestamp(beam.DoFn):
    """
    Parses each raw Pub/Sub message (bytes → dict) and yields a
    TimestampedValue so Apache Beam uses event_time (not arrival time)
    as the event clock for windowing.

    Also handles:
    - Malformed JSON (skipped silently — fault tolerance)
    - Missing event_time field (skipped)
    - Timezone-naive timestamps (assumed UTC)
    """
    def process(self, element):
        try:
            record = json.loads(element.decode("utf-8"))

            # Parse event_time string → unix timestamp float
            raw_ts = record.get("event_time", "")
            if not raw_ts:
                return  # Skip records with no timestamp

            # Handle both "Z" suffix and "+00:00" offset formats
            raw_ts = raw_ts.replace("Z", "+00:00")
            dt = datetime.fromisoformat(raw_ts)

            # Make timezone-aware if naive (assume UTC)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)

            unix_ts = dt.timestamp()

            # TimestampedValue tells Beam: use this unix_ts as the event clock
            # This is what enables proper 5-minute EVENT-TIME windowing
            yield TimestampedValue(record, unix_ts)

        except (json.JSONDecodeError, ValueError, KeyError):
            # Silently drop malformed records — do not crash the pipeline
            pass


# ─── STEP 2: FILTER ONLY RELEVANT EVENT TYPES ──────────────────────────────
class FilterRelevantEvents(beam.DoFn):
    """
    Keeps only:
      - ride_request     → contributes to demand_count
      - driver_available → contributes to supply_count

    Drops:
      - ride_accepted, ride_started, ride_completed
        (these are lifecycle events, not supply/demand signals)
    """
    def process(self, element):
        if element.get("event_type") in RELEVANT_EVENTS:
            yield element


# ─── MAIN PIPELINE ──────────────────────────────────────────────────────────
def run():
    options = PipelineOptions(
        runner           = "DataflowRunner",
        project          = PROJECT_ID,
        region           = REGION,
        streaming        = True,           # Required for Pub/Sub infinite stream
        save_main_session = True,           # Needed when DoFns use global imports
        temp_location    = f"gs://{BUCKET}/temp",
        staging_location = f"gs://{BUCKET}/staging",
        job_name         = "rideshare-stream-to-bq",
    )

    with beam.Pipeline(options=options) as p:

        events = (
            p

            # ── 1. Read raw bytes from Pub/Sub subscription ──────────────
            | "ReadPubSub"     >> ReadFromPubSub(subscription=SUBSCRIPTION)

            # ── 2. Parse JSON & stamp each event with its own event_time ─
            #       Without this, Beam would use processing time (arrival
            #       time), which means late events would fall in the WRONG
            #       5-minute window and distort surge calculations.
            | "ParseAndStamp"  >> beam.ParDo(ParseJsonWithTimestamp())

            # ── 3. Apply 5-minute tumbling window with 5-min watermark ───
            #
            #   FixedWindows(300):
            #     Divides infinite stream into non-overlapping 5-min buckets
            #     e.g.  [12:00–12:05), [12:05–12:10), [12:10–12:15) ...
            #
            #   allowed_lateness=300:
            #     Watermark — hold each window open 5 extra minutes AFTER
            #     its end time, to catch late-arriving events.
            #     e.g. The [12:00–12:05) window won't close until 12:10.
            #     Events from data_generator.py that arrive 1–5 mins late
            #     will still be counted in the correct window.
            #
            #   AfterWatermark(late=AfterCount(1)):
            #     Fire results once watermark passes window end.
            #     For any late record that arrives after the watermark,
            #     fire immediately (AfterCount(1)) so it's not lost.
            #
            #   AccumulationMode.ACCUMULATING:
            #     When a late event triggers a re-fire, accumulate it
            #     with the previous results (don't discard earlier counts).
            | "TumblingWindow" >> beam.WindowInto(
                FixedWindows(5 * 60),                    # 5-minute windows
                trigger=AfterWatermark(
                    late=AfterCount(1)                   # emit late records immediately
                ),
                allowed_lateness=5 * 60,                # 5-minute watermark delay
                accumulation_mode=AccumulationMode.ACCUMULATING,
            )

            # ── 4. Drop non-signal events ─────────────────────────────────
            | "FilterEvents"   >> beam.ParDo(FilterRelevantEvents())
        )

        # ── 5. Write every windowed event to BigQuery raw_events ─────────
        #       The bq_transform_dag.py will later read this table every
        #       5 minutes and compute surge_multiplier per zone per window.
        (
            events
            | "WriteToBigQuery" >> WriteToBigQuery(
                BQ_TABLE,
                schema             = BQ_SCHEMA,
                write_disposition  = BigQueryDisposition.WRITE_APPEND,
                create_disposition = BigQueryDisposition.CREATE_IF_NEEDED,
            )
        )


if __name__ == "__main__":
    run()
