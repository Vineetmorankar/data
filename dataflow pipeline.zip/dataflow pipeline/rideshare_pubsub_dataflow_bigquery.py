from datetime import datetime, timedelta
from airflow import DAG

from airflow.providers.google.cloud.operators.pubsub import (
    PubSubCreateTopicOperator,
    PubSubCreateSubscriptionOperator,
)
from airflow.providers.apache.beam.operators.beam import BeamRunPythonPipelineOperator
from airflow.providers.google.cloud.operators.bigquery import (
    BigQueryCreateEmptyDatasetOperator,
    BigQueryInsertJobOperator,
)
from airflow.providers.google.cloud.operators.dataflow import DataflowConfiguration


# ───────────────── CONFIG ─────────────────

PROJECT_ID = "sprint-project123"
REGION     = "europe-west8"
BUCKET     = "ridesh"

DATASET      = "analytics"
TOPIC        = "spark-21-ridesharing"
SUBSCRIPTION = "spark-21-ridesharing-sub"

RAW_TABLE = "raw_events"
AGG_TABLE = "zone_surge_metrics"
VIEW_NAME = "looker_surge_view"


# ─────────────── BIGQUERY SQL ─────────────

TRANSFORM_SQL = f"""
CREATE OR REPLACE TABLE `{PROJECT_ID}.{DATASET}.{AGG_TABLE}` AS
WITH base AS (
  SELECT
    TIMESTAMP_TRUNC(event_time, MINUTE, 5) AS window_start,
    TIMESTAMP_ADD(
      TIMESTAMP_TRUNC(event_time, MINUTE, 5),
      INTERVAL 5 MINUTE
    ) AS window_end,
    zone_id,
    COUNTIF(event_type = 'ride_request')     AS demand_count,
    COUNTIF(event_type = 'driver_available') AS supply_count
  FROM `{PROJECT_ID}.{DATASET}.{RAW_TABLE}`
  WHERE event_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)
  GROUP BY window_start, window_end, zone_id
)
SELECT
  window_start,
  window_end,
  zone_id,
  demand_count,
  supply_count,
  LEAST(
    5.0,
    GREATEST(
      1.0,
      SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1))
    )
  ) AS surge_multiplier,
  SAFE_DIVIDE(demand_count, GREATEST(supply_count, 1)) > 2.0 AS is_hotspot
FROM base;
"""

VIEW_SQL = f"""
CREATE OR REPLACE VIEW `{PROJECT_ID}.{DATASET}.{VIEW_NAME}` AS
SELECT *
FROM `{PROJECT_ID}.{DATASET}.{AGG_TABLE}`
ORDER BY window_start DESC, surge_multiplier DESC;
"""


# ─────────────── DAG DEFAULTS ─────────────

default_args = {
    "owner": "airflow",
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "start_date": datetime(2024, 1, 1),
    "depends_on_past": False,
}


# ─────────────── DAG ─────────────────────

with DAG(
    dag_id="rideshare_pubsub_dataflow_bigquery",
    schedule_interval=None,
    default_args=default_args,
    catchup=False,
    tags=["pubsub", "dataflow", "bigquery", "looker"],
) as dag:

    create_topic = PubSubCreateTopicOperator(
        task_id="create_pubsub_topic",
        project_id=PROJECT_ID,
        topic=TOPIC,
        fail_if_exists=False,
        do_xcom_push=False,
    )

    create_subscription = PubSubCreateSubscriptionOperator(
        task_id="create_pubsub_subscription",
        project_id=PROJECT_ID,
        topic=TOPIC,
        subscription=SUBSCRIPTION,
        fail_if_exists=False,
        do_xcom_push=False,
    )

    create_dataset = BigQueryCreateEmptyDatasetOperator(
        task_id="create_bq_dataset",
        project_id=PROJECT_ID,
        dataset_id=DATASET,
        location="EU",
        if_exists="ignore",
    )

    create_raw_table = BigQueryInsertJobOperator(
        task_id="create_raw_table",
        configuration={
            "query": {
                "query": f"""
                CREATE TABLE IF NOT EXISTS
                `{PROJECT_ID}.{DATASET}.{RAW_TABLE}` (
                  request_id   STRING,
                  rider_id     STRING,
                  driver_id    STRING,
                  event_type   STRING,
                  pickup_lat   FLOAT64,
                  pickup_lon   FLOAT64,
                  dropoff_lat  FLOAT64,
                  dropoff_lon  FLOAT64,
                  zone_id      STRING,
                  event_time   TIMESTAMP
                )
                PARTITION BY DATE(event_time)
                """,
                "useLegacySql": False,
            }
        },
    )

    start_dataflow = BeamRunPythonPipelineOperator(
        task_id="run_dataflow_streaming",
        py_file=f"gs://{BUCKET}/dataflow/rideshare_streaming_pipeline.py",
        py_interpreter="python3",
        pipeline_options={
            "project": PROJECT_ID,
            "region": REGION,
            "runner": "DataflowRunner",   # ✅ CRITICAL FIX
            "streaming": True,
            "temp_location": f"gs://{BUCKET}/temp",
            "staging_location": f"gs://{BUCKET}/staging",
            "job_name": "rideshare-stream-to-bq",
        },
        dataflow_config=DataflowConfiguration(
            project_id=PROJECT_ID,
            location=REGION,
            wait_until_finished=False,
        ),
    )

    transform_metrics = BigQueryInsertJobOperator(
        task_id="compute_surge_metrics",
        configuration={
            "query": {
                "query": TRANSFORM_SQL,
                "useLegacySql": False,
            }
        },
    )

    create_looker_view = BigQueryInsertJobOperator(
        task_id="create_looker_view",
        configuration={
            "query": {
                "query": VIEW_SQL,
                "useLegacySql": False,
            }
        },
    )

    # ───────────── DEPENDENCIES ─────────────

    create_topic >> create_subscription
    create_dataset >> create_raw_table
    [create_subscription, create_raw_table] >> start_dataflow
    start_dataflow >> transform_metrics >> create_looker_view